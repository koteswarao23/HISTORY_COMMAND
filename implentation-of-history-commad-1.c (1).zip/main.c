#include<stdio.h>
#include<string.h>
#include<stdlib.h>


void history(char *path)
{
        char l[100];
        int i=0;
        FILE *fp=fopen(path,"r");
        if(fp==NULL)
        {
                perror("fopen");
                exit(0);
        }
        else
        {

           while(fgets(l,100,fp)!=NULL)
                           {
                           printf("%d\t%s",i+1,l);
                          i++;
                           }
        }
        fclose(fp);
}


int main(int arg,char *argc[])
{
         if(arg!=2)
         {
                 printf("input format:./a.out /home/ enter your username/.bash_history\n");
                 exit(0);
         }

        history(argc[1]);

 }